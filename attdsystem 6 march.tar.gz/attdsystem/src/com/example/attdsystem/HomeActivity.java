package com.example.attdsystem;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class HomeActivity extends Activity {
	
	
	  public void onCreate(Bundle savedInstanceState)
	    {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.activity_main);
	        
	        
	    }

	  public void nxtmethod (View v)
	  {
		       // start the home activity
               Intent intent = new Intent(HomeActivity.this, detailform.class);
               HomeActivity.this.startActivity(intent);
          }
	  
}
